import React from 'react'
import { getImageUrl } from '../../utils';
import styles from "./Hero.module.css";

export default function Hero() {
  return (
    <section className={styles.container}>
      <div className={styles.content}>
        <h1 className={styles.title}>Hi, I'm Priti Bhosale</h1>
        <p className={styles.description}>
        A passionate MERN stack developer with strong Java and frontend skills. I love turning ideas into real web applications with user-focused design. Reach out if you'd like to learn more!
        </p>
        <a href="https://drive.google.com/file/d/1uupexyi_ZfaY5ymG22meHNG4ZLPb6gf9/view?usp=sharing"  className={styles.contactBtn}>
          View Resume/CV
        </a>
      </div>
      <img
        src={getImageUrl("hero/professionalphoto.jpeg")}
        alt="Hero image of me"
        className={styles.heroImg}
      />
      <div className={styles.topBlur} />
      <div className={styles.bottomBlur} />
    </section>
  );
}
